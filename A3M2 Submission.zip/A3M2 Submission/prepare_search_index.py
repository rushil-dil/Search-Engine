import json
import os

def prepare(index_path="index/inverted_index.json", out_dir="search_index"):
    os.makedirs(out_dir, exist_ok=True)

    postings_path = os.path.join(out_dir, "postings.jsonl")
    lexicon_path = os.path.join(out_dir, "lexicon.json")

    with open(index_path, "r", encoding="utf-8") as f:
        index = json.load(f)

    lexicon = {}

    with open(postings_path, "w", encoding="utf-8") as out:
        for term in sorted(index):
            offset = out.tell()
            line = json.dumps(index[term], separators=(",", ":"))
            out.write(line + "\n")
            lexicon[term] = [offset, len(line.encode("utf-8")) + 1, len(index[term])]

    with open(lexicon_path, "w", encoding="utf-8") as f:
        json.dump(lexicon, f, separators=(",", ":"))

    print("Search index prepared.")
    print(f"Terms: {len(lexicon)}")

if __name__ == "__main__":
    prepare()