import json
import math
import re
import time
from nltk.stem import PorterStemmer

TOKEN_RE = re.compile(r"[A-Za-z0-9]+")
STEMMER = PorterStemmer()

def tokenize_query(query):
    return [STEMMER.stem(t.lower()) for t in TOKEN_RE.findall(query)]

def load_postings(term, lexicon, postings_file):
    if term not in lexicon:
        return []

    offset, size, df = lexicon[term]
    postings_file.seek(offset)
    line = postings_file.readline()
    return json.loads(line), df

def search(query, lexicon, doc_ids, postings_path):
    terms = tokenize_query(query)

    if not terms:
        return []

    postings_data = []

    with open(postings_path, "r", encoding="utf-8") as postings_file:
        for term in terms:
            postings, df = load_postings(term, lexicon, postings_file)
            if not postings:
                return []
            postings_data.append((term, postings, df))

    doc_sets = [set(doc_id for doc_id, tf in postings) for _, postings, _ in postings_data]
    matching_docs = set.intersection(*doc_sets)

    scores = {}
    total_docs = len(doc_ids)

    for term, postings, df in postings_data:
        idf = math.log((total_docs + 1) / (df + 1)) + 1
        for doc_id, tf in postings:
            if doc_id in matching_docs:
                scores[doc_id] = scores.get(doc_id, 0) + (1 + math.log(tf)) * idf

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    return [(doc_ids[str(doc_id)], score) for doc_id, score in ranked[:5]]

def main():
    with open("search_index/lexicon.json", "r", encoding="utf-8") as f:
        lexicon = json.load(f)

    with open("index/doc_ids.json", "r", encoding="utf-8") as f:
        doc_ids = json.load(f)

    postings_path = "search_index/postings.jsonl"

    while True:
        query = input("\nSearch: ").strip()

        if query.lower() in {"quit", "exit"}:
            break

        start = time.perf_counter()
        results = search(query, lexicon, doc_ids, postings_path)
        elapsed = (time.perf_counter() - start) * 1000

        print(f"\nQuery time: {elapsed:.2f} ms")

        if not results:
            print("No results found.")
            continue

        for i, (url, score) in enumerate(results, start=1):
            print(f"{i}. {url}  score={score:.4f}")

if __name__ == "__main__":
    main()